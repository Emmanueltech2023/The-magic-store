import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatPrice(price: number) {
  return new Intl.NumberFormat("en-NG", {
    style: "currency",
    currency: "NGN",
    maximumFractionDigits: 0,
  }).format(price).replace("NGN", "₦");
}

export function getWhatsAppLink(productName: string, price: number) {
  const message = `Hi, I want to order ${productName} (₦${price.toLocaleString()})`;
  return `https://wa.me/2347000000000?text=${encodeURIComponent(message)}`;
}

export function getWhatsAppCartLink(items: { name: string; price: number; quantity: number }[], total: number) {
  const itemSummary = items.map(i => `- ${i.name} (${i.quantity}x) @ ₦${i.price.toLocaleString()}`).join("\n");
  const message = `Hi, I want to place an order:\n\n${itemSummary}\n\nTotal: ₦${total.toLocaleString()}`;
  return `https://wa.me/2347000000000?text=${encodeURIComponent(message)}`;
}
