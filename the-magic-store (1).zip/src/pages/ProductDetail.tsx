import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import { ShoppingCart, Heart, Share2, Sparkle, MessageCircle, ArrowLeft, Plus, Minus, Check } from 'lucide-react';
import { useCartStore } from '../lib/cartStore';
import { Skeleton } from '../components/Skeleton';
import { formatPrice, getWhatsAppLink } from '../lib/utils';

import { supabase } from '../lib/supabase';

export const ProductDetail = () => {
  const { id } = useParams();
  const [product, setProduct] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [quantity, setQuantity] = useState(1);
  const [activeImage, setActiveImage] = useState(0);
  const [isAdded, setIsAdded] = useState(false);
  const addItem = useCartStore((state) => state.addItem);

  useEffect(() => {
    const fetchProduct = async () => {
      setIsLoading(true);
      const { data } = await supabase.from('products').select('*').eq('id', id).single();
      
      if (data) {
        setProduct({
          ...data,
          details: [
            { label: 'Category', value: data.category },
            { label: 'Stock', value: data.stock > 0 ? 'In Stock' : 'Out of Stock' },
            { label: 'Brand', value: 'Korean' },
          ]
        });
      } else {
        // Mock fallback if product not found and it looks like a mock ID
        const mockProducts: Record<string, any> = {
          '1': {
            id: '1',
            name: 'COSRX Snail Mucin Essence',
            price: 15500,
            category: 'Serums',
            description: 'A lightweight essence that provides deep hydration and improves skin texture.',
            images: ['https://images.unsplash.com/photo-1556228578-0d85b1a4d571?q=80&w=800&auto=format&fit=crop'],
            details: [{ label: 'Skin Type', value: 'All' }, { label: 'Size', value: '100ml' }]
          }
        };
        setProduct(mockProducts[id || ''] || mockProducts['1']);
      }
      setIsLoading(false);
    };
    fetchProduct();
  }, [id]);

  const handleAddToCart = () => {
    if (!product) return;
    addItem({
      id: product.id,
      name: product.name,
      price: product.price,
      image: product.images[0],
    });
    setIsAdded(true);
    setTimeout(() => setIsAdded(false), 2000);
  };

  const handleWhatsAppChat = () => {
    if (!product) return;
    window.open(getWhatsAppLink(product.name, product.price), '_blank');
  };

  if (isLoading) {
    return (
      <div className="pt-24 pb-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center gap-2 mb-10">
            <Skeleton className="h-4 w-32" />
            <span className="text-text-muted text-xs">/</span>
            <Skeleton className="h-4 w-24" />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
            <div className="space-y-6">
              <Skeleton className="aspect-[4/5] rounded-[48px] w-full" />
              <div className="grid grid-cols-4 gap-4">
                {Array.from({ length: 4 }).map((_, idx) => (
                  <Skeleton key={idx} className="aspect-square rounded-2xl w-full" />
                ))}
              </div>
            </div>

            <div className="flex flex-col">
              <div className="mb-8">
                <Skeleton className="h-4 w-32 mb-4" />
                <Skeleton className="h-12 w-full mb-4" />
                <Skeleton className="h-8 w-40" />
              </div>

              <div className="space-y-4 mb-10">
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-4 w-3/4" />
              </div>

              <div className="grid grid-cols-2 gap-6 mb-10">
                {Array.from({ length: 4 }).map((_, idx) => (
                  <Skeleton key={idx} className="h-16 rounded-2xl w-full" />
                ))}
              </div>

              <div className="space-y-6">
                <div className="flex gap-4">
                  <Skeleton className="h-16 flex-grow rounded-full" />
                  <Skeleton className="h-16 w-16 rounded-full" />
                  <Skeleton className="h-16 w-16 rounded-full" />
                </div>
                <Skeleton className="h-24 rounded-[40px] w-full" />
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!product) return <div className="pt-40 text-center font-display text-2xl font-bold">Magic lost in transit.</div>;

  return (
    <div className="pt-24 pb-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Breadcrumb */}
        <div className="flex items-center gap-2 mb-10">
          <Link to="/shop" className="flex items-center gap-2 text-text-muted hover:text-primary transition-colors text-sm font-medium">
             <ArrowLeft className="w-4 h-4" />
             Back to Shop
          </Link>
          <span className="text-text-muted text-xs">/</span>
          <span className="text-primary font-bold text-sm tracking-widest uppercase">{product.category}</span>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
          {/* Image Gallery */}
          <div className="space-y-6">
            <motion.div 
               layoutId="main-image"
               className="aspect-[4/5] rounded-[48px] overflow-hidden bg-secondary/5 border border-secondary/10 soft-shadow"
            >
              <img 
                src={product.images[activeImage]} 
                alt={product.name} 
                className="w-full h-full object-cover"
              />
            </motion.div>
            
            <div className="grid grid-cols-4 gap-4">
              {product.images.map((img: string, idx: number) => (
                <button 
                  key={idx}
                  onClick={() => setActiveImage(idx)}
                  className={`aspect-square rounded-2xl overflow-hidden border-2 transition-all ${
                    activeImage === idx ? 'border-primary shadow-lg shadow-primary/20 scale-105' : 'border-transparent opacity-60 hover:opacity-100'
                  }`}
                >
                  <img src={img} alt={product.name} className="w-full h-full object-cover" />
                </button>
              ))}
            </div>
          </div>

          {/* Product Details */}
          <div className="flex flex-col">
            <div className="mb-8">
              <div className="flex items-center gap-2 text-primary mb-4 font-bold text-xs uppercase tracking-[0.2em]">
                <Sparkle className="w-4 h-4" />
                <span>Customer Favorite</span>
              </div>
              <h1 className="text-4xl md:text-5xl font-display font-bold leading-tight mb-4">{product.name}</h1>
              <p className="text-3xl font-display font-bold text-primary">{formatPrice(product.price)}</p>
            </div>

            <div className="prose prose-sm text-text-muted mb-10 max-w-none">
              <p className="leading-relaxed text-base italic mb-6">"{product.description}"</p>
              
              <div className="grid grid-cols-2 gap-6 mb-10">
                {product.details.map((detail: any, idx: number) => (
                  <div key={idx} className="bg-white p-4 rounded-2xl border border-secondary/10">
                    <p className="text-[10px] text-text-muted uppercase tracking-widest font-bold mb-1">{detail.label}</p>
                    <p className="text-sm font-bold text-text">{detail.value}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Actions */}
            <div className="mt-auto space-y-6">
              <div className="flex flex-col sm:flex-row gap-4">
                <button 
                  onClick={handleAddToCart}
                  disabled={isAdded}
                  className={`flex-grow h-16 rounded-full font-bold flex items-center justify-center gap-3 transition-all transform active:scale-95 ${
                    isAdded ? 'bg-green-500 text-white' : 'bg-primary text-white hover:shadow-xl hover:shadow-primary/30'
                  }`}
                >
                  {isAdded ? (
                    <>
                      <Check className="w-6 h-6" />
                      Added to Cart
                    </>
                  ) : (
                    <>
                      <ShoppingCart className="w-6 h-6" />
                      Add Selection to Cart
                    </>
                  )}
                </button>
                <button className="h-16 w-16 bg-white border border-secondary/20 text-text rounded-full flex items-center justify-center hover:bg-secondary/10 transition-colors">
                  <Heart className="w-6 h-6" />
                </button>
                <button className="h-16 w-16 bg-white border border-secondary/20 text-text rounded-full flex items-center justify-center hover:bg-secondary/10 transition-colors">
                  <Share2 className="w-6 h-6" />
                </button>
              </div>

              <div className="p-8 rounded-[40px] bg-secondary/10 border border-secondary/20 relative overflow-hidden">
                <div className="relative z-10 flex items-center justify-between gap-6">
                   <div>
                     <p className="text-sm font-bold mb-1">Need skincare advice?</p>
                     <p className="text-xs text-text-muted">Chat with our resident esthetician for a custom routine.</p>
                   </div>
                   <button 
                    onClick={handleWhatsAppChat}
                    className="flex items-center gap-2 px-6 py-3 bg-[#25D366] text-white rounded-full font-bold text-sm shadow-md hover:shadow-lg transition-all active:scale-95"
                   >
                     <MessageCircle className="w-4 h-4 fill-white" />
                     Chat
                   </button>
                </div>
                <div className="absolute top-0 right-0 -translate-y-4 translate-x-4 w-40 h-40 bg-primary/20 rounded-full blur-2xl -z-0" />
              </div>
            </div>

            {/* Tabs placeholder */}
            <div className="mt-16 space-y-8">
               <div className="border-b border-secondary/20 flex gap-12">
                  <span className="pb-4 border-b-2 border-primary font-bold text-sm">Description</span>
                  <span className="pb-4 text-text-muted font-bold text-sm cursor-pointer hover:text-text">Usage</span>
                  <span className="pb-4 text-text-muted font-bold text-sm cursor-pointer hover:text-text">Ingredients</span>
               </div>
               <div className="text-text-muted leading-relaxed text-sm">
                  {product.usage}
               </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
