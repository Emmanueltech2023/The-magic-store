import React, { useEffect, useState } from 'react';
import { Hero } from '../components/Hero';
import { ProductCard } from '../components/ProductCard';
import { Skeleton } from '../components/Skeleton';
import { motion } from 'motion/react';
import { Sparkle, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import { supabase } from '../lib/supabase';

export const Home = () => {
  const [featuredProducts, setFeaturedProducts] = useState<any[]>([]);
  const [categories, setCategories] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchHomeData = async () => {
      setIsLoading(true);
      try {
        const { data } = await supabase.from('products').select('*').limit(8);
        
        const mockProducts = [
          { id: '1', name: 'COSRX Snail Mucin Essence', price: 15500, category: 'Serums', image: 'https://images.unsplash.com/photo-1556228578-0d85b1a4d571?q=80&w=600&auto=format&fit=crop', badge: 'Best Seller' },
          { id: '2', name: 'Beauty of Joseon Sunscreen', price: 18000, category: 'Protection', image: 'https://images.unsplash.com/photo-1556228720-195a672e8a03?q=80&w=600&auto=format&fit=crop', badge: 'New' },
          { id: '3', name: 'Laneige Lip Sleeping Mask', price: 12000, category: 'Lips', image: 'https://images.unsplash.com/photo-1596462502278-27bfdc403328?q=80&w=600&auto=format&fit=crop' },
          { id: '4', name: 'Anua Heartleaf Toner', price: 21500, category: 'Toners', image: 'https://images.unsplash.com/photo-1620916566398-39f1143ab7be?q=80&w=600&auto=format&fit=crop' },
        ];

        if (data && data.length > 0) {
          setFeaturedProducts(data.map(p => ({
            ...p,
            image: p.images[0]
          })));
        } else {
          setFeaturedProducts(mockProducts);
        }
      } finally {
        setIsLoading(false);
      }
    };

    const fetchCategories = async () => {
      const mockCategories = [
        { id: 'cat1', name: 'K-Drinks', icon: '🧃', count: 18 },
        { id: 'cat2', name: 'K-Foods', icon: '🍜', count: 32 },
        { id: 'cat3', name: 'BTS Merch', icon: '💜', count: 95 },
        { id: 'cat4', name: 'Lifestyle', icon: '🎒', count: 48 },
      ];
      setCategories(mockCategories);
    };

    fetchHomeData();
    fetchCategories();
  }, []);

  return (
    <div className="pb-20">
      <Hero />

      {/* Categories Section */}
      <section id="categories" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-end mb-12">
            <div>
              <div className="flex items-center gap-2 text-primary mb-4 font-bold text-sm tracking-widest uppercase">
                <Sparkle className="w-4 h-4" />
                <span>Shop by category</span>
              </div>
              <h2 className="text-3xl md:text-5xl font-display font-bold">Magical Categories</h2>
            </div>
            <Link to="/shop" className="text-primary font-bold flex items-center gap-2 hover:translate-x-1 transition-transform sm:block hidden">
              View All <ArrowRight className="w-4 h-4 inline" />
            </Link>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {isLoading ? (
              Array.from({ length: 4 }).map((_, idx) => (
                <div key={idx} className="h-48 rounded-[40px] bg-slate-100 p-8 flex flex-col items-center justify-center">
                  <Skeleton className="w-16 h-16 rounded-full mb-4" />
                  <Skeleton className="w-24 h-6 mb-2" />
                  <Skeleton className="w-16 h-4" />
                </div>
              ))
            ) : (
              categories.map((cat, idx) => (
                <motion.div
                  key={cat.id}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ delay: idx * 0.1 }}
                  viewport={{ once: true }}
                  className="group relative h-48 rounded-[40px] bg-secondary/10 border border-secondary/5 p-8 flex flex-col items-center justify-center text-center hover:bg-primary transition-all duration-500 cursor-pointer overflow-hidden"
                >
                  <div className="absolute top-0 right-0 -translate-y-4 translate-x-4 w-24 h-24 bg-white/10 rounded-full blur-xl group-hover:bg-white/20 transition-all" />
                  <span className="text-5xl mb-4 group-hover:scale-125 transition-transform duration-500">{cat.icon}</span>
                  <h3 className="font-display text-xl font-bold group-hover:text-white transition-colors">{cat.name}</h3>
                  <p className="text-xs text-text-muted group-hover:text-white/80 transition-colors uppercase tracking-widest font-bold mt-1">
                    {cat.count}+ Products
                  </p>
                </motion.div>
              ))
            )}
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-20 relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-full bg-primary/5 -skew-y-3 origin-top-left -z-10" />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <div className="flex items-center justify-center gap-2 text-primary mb-4 font-bold text-sm tracking-widest uppercase">
              <Sparkle className="w-4 h-4" />
              <span>The Magic Chow</span>
            </div>
            <h2 className="text-3xl md:text-5xl font-display font-bold mb-6">K-Food Favorites</h2>
            <p className="text-text-muted max-w-2xl mx-auto">
              From Samyang to Banana Milk, get the snack experience straight from the streets of Seoul.
            </p>
          </div>

          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 md:gap-8">
            {isLoading ? (
              Array.from({ length: 4 }).map((_, idx) => (
                <div key={idx} className="space-y-4">
                  <Skeleton className="aspect-square rounded-[32px] w-full" />
                  <Skeleton className="h-6 w-3/4" />
                  <Skeleton className="h-4 w-1/2" />
                </div>
              ))
            ) : (
              featuredProducts.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))
            )}
          </div>

          <div className="mt-16 text-center">
            <Link 
              to="/shop" 
              className="inline-flex items-center justify-center px-10 py-4 border-2 border-primary text-primary rounded-full font-bold hover:bg-primary hover:text-white transition-all shadow-lg shadow-primary/10"
            >
              Discover More Magic
            </Link>
          </div>
        </div>
      </section>

      {/* Promo Section */}
      <section className="py-12 md:py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="relative rounded-[60px] bg-primary/90 overflow-hidden p-12 md:p-24 text-center md:text-left">
             <div className="absolute top-0 right-0 w-[500px] h-full bg-white/10 -skew-x-12 -z-0" />
             <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-12">
                <div className="max-w-xl">
                  <h2 className="text-4xl md:text-6xl font-display font-bold text-white mb-6">Join the Magic Circle</h2>
                  <p className="text-white/80 text-lg mb-8 leading-relaxed">
                    Get updates on the latest merch drops, special snack restocks, and exclusive WhatsApp-only discounts.
                  </p>
                  <div className="flex flex-col sm:flex-row gap-4">
                    <input 
                      type="email" 
                      placeholder="Your magic email..." 
                      className="flex-grow px-8 py-4 rounded-full bg-white/20 border border-white/30 text-white placeholder:text-white/50 focus:outline-none focus:bg-white/30 transition-all font-medium"
                    />
                    <button className="px-10 py-4 bg-white text-primary rounded-full font-bold hover:bg-secondary transition-all shrink-0">
                      I'm Ready ✨
                    </button>
                  </div>
                </div>
                <div className="hidden lg:block w-72 h-72 bg-white/20 rounded-full border-[20px] border-white/10 flex items-center justify-center animate-pulse">
                   <Sparkle className="w-32 h-32 text-white" />
                </div>
             </div>
          </div>
        </div>
      </section>
    </div>
  );
};
