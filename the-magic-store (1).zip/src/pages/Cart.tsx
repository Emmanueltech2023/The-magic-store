import React from 'react';
import { Link } from 'react-router-dom';
import { useCartStore } from '../lib/cartStore';
import { Trash2, Plus, Minus, ShoppingBag, ArrowRight, Sparkle } from 'lucide-react';
import { formatPrice, getWhatsAppCartLink } from '../lib/utils';
import { motion, AnimatePresence } from 'motion/react';

export const Cart = () => {
  const { items, updateQuantity, removeItem, getTotal } = useCartStore();
  const total = getTotal();

  const handleWhatsAppOrder = () => {
    const link = getWhatsAppCartLink(items, total);
    window.open(link, '_blank');
  };

  if (items.length === 0) {
    return (
      <div className="pt-32 pb-20 px-4 min-h-[70vh] flex flex-col items-center justify-center text-center">
        <motion.div
           initial={{ scale: 0.9, opacity: 0 }}
           animate={{ scale: 1, opacity: 1 }}
           className="w-24 h-24 bg-secondary/20 rounded-full flex items-center justify-center mb-8"
        >
          <ShoppingBag className="w-10 h-10 text-primary" />
        </motion.div>
        <h1 className="text-3xl font-display font-bold mb-4">Your Magical Cart is Empty</h1>
        <p className="text-text-muted mb-10 max-w-sm">
          It looks like you haven't added any magic yet. Start exploring our Korean curated products.
        </p>
        <Link 
          to="/shop" 
          className="bg-primary text-white px-10 py-4 rounded-full font-bold hover:shadow-xl hover:shadow-primary/30 transition-all flex items-center gap-2 group"
        >
          Start Shopping
          <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
        </Link>
      </div>
    );
  }

  return (
    <div className="pt-24 pb-20 bg-background/50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center gap-2 mb-8">
           <Link to="/shop" className="text-text-muted hover:text-primary font-bold text-sm">Shop</Link>
           <span className="text-text-muted text-sm">/</span>
           <span className="font-bold text-sm">Cart</span>
        </div>

        <h1 className="text-4xl font-display font-bold mb-12">Your Selections</h1>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          {/* Cart Items */}
          <div className="lg:col-span-2 space-y-6">
            <AnimatePresence>
              {items.map((item) => (
                <motion.div
                  key={item.id}
                  layout
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  className="bg-white rounded-[32px] p-6 flex flex-col sm:flex-row items-center gap-6 soft-shadow relative group border border-secondary/10"
                >
                  <div className="w-24 h-24 sm:w-32 sm:h-32 bg-secondary/10 rounded-2xl overflow-hidden shrink-0">
                    <img src={item.image} alt={item.name} className="w-full h-full object-cover" />
                  </div>
                  
                  <div className="flex-grow text-center sm:text-left">
                    <h3 className="font-display text-xl font-bold mb-2">{item.name}</h3>
                    <p className="font-bold text-primary text-lg mb-4">{formatPrice(item.price)}</p>
                    
                    <div className="flex items-center justify-center sm:justify-start gap-4">
                       <div className="flex items-center bg-secondary/10 rounded-full p-1 border border-secondary/20">
                          <button 
                            onClick={() => updateQuantity(item.id, -1)}
                            className="p-1.5 hover:bg-white rounded-full transition-colors"
                          >
                            <Minus className="w-4 h-4" />
                          </button>
                          <span className="w-10 text-center font-bold">{item.quantity}</span>
                          <button 
                            onClick={() => updateQuantity(item.id, 1)}
                            className="p-1.5 hover:bg-white rounded-full transition-colors"
                          >
                            <Plus className="w-4 h-4" />
                          </button>
                       </div>
                    </div>
                  </div>

                  <button 
                    onClick={() => removeItem(item.id)}
                    className="absolute top-6 right-6 p-2 text-text-muted hover:text-red-500 transition-colors opacity-0 group-hover:opacity-100"
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>

          {/* Order Summary */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-[40px] p-10 soft-shadow sticky top-32 border border-secondary/10">
              <h2 className="font-display text-2xl font-bold mb-8 flex items-center gap-2">
                Order Summary
                <Sparkle className="w-5 h-5 text-primary" />
              </h2>
              
              <div className="space-y-4 mb-8">
                <div className="flex justify-between text-text-muted">
                  <span>Subtotal</span>
                  <span className="font-bold">{formatPrice(total)}</span>
                </div>
                <div className="flex justify-between text-text-muted text-sm italic">
                  <span>Delivery fee</span>
                  <span>Calculated on WhatsApp</span>
                </div>
                <div className="pt-4 border-t border-secondary/10 flex justify-between items-center">
                  <span className="font-display text-xl font-bold">Total</span>
                  <span className="font-display text-2xl font-bold text-primary">{formatPrice(total)}</span>
                </div>
              </div>

              <button 
                onClick={handleWhatsAppOrder}
                className="w-full bg-[#25D366] text-white py-5 rounded-full font-bold flex items-center justify-center gap-3 hover:shadow-xl hover:shadow-[#25D366]/30 transition-all transform hover:scale-[1.02]"
              >
                Order via WhatsApp
                <ArrowRight className="w-5 h-5" />
              </button>
              
              <p className="mt-6 text-center text-[10px] text-text-muted uppercase tracking-widest font-bold">
                Order instantly • safe & secure
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
