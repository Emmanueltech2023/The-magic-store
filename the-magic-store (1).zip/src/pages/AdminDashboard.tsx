import React, { useState, useEffect } from 'react';
import { Routes, Route, Link, useNavigate, useLocation } from 'react-router-dom';
import { 
  BarChart3, 
  Package, 
  Plus, 
  Settings, 
  LogOut, 
  Search, 
  Edit2, 
  Trash2, 
  ExternalLink,
  ChevronRight,
  Image as ImageIcon,
  Loader2,
  X,
  Sparkles
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { supabase } from '../lib/supabase';
import { IKUpload, IKContext } from 'imagekitio-react';
import { cn, formatPrice } from '../lib/utils';

// Types
interface Product {
  id: string;
  name: string;
  price: number;
  category: string;
  stock: number;
  images: string[];
  description: string;
  created_at?: string;
}

export const AdminDashboard = () => {
  const location = useLocation();
  
  return (
    <div className="flex min-h-screen bg-slate-50 pt-0">
      {/* Sidebar */}
      <aside className="w-64 bg-white border-r border-slate-200 hidden md:flex flex-col sticky top-0 h-screen">
        <div className="p-8 border-b border-slate-100 flex items-center gap-3">
           <div className="w-10 h-10 bg-primary/20 rounded-xl flex items-center justify-center text-primary">
              <Sparkles className="w-6 h-6" />
           </div>
           <span className="font-display font-bold text-xl">Admin Hub</span>
        </div>
        <nav className="p-6 space-y-2 flex-grow">
          <Link to="/admin" className={cn("flex items-center gap-3 px-4 py-3 rounded-2xl transition-all font-bold text-sm", location.pathname === '/admin' ? 'bg-primary text-white shadow-lg shadow-primary/20' : 'text-slate-500 hover:bg-slate-100')}>
            <BarChart3 className="w-5 h-5" />
            Dashboard
          </Link>
          <Link to="/admin/products" className={cn("flex items-center gap-3 px-4 py-3 rounded-2xl transition-all font-bold text-sm", location.pathname.includes('/admin/products') ? 'bg-primary text-white shadow-lg shadow-primary/20' : 'text-slate-500 hover:bg-slate-100')}>
            <Package className="w-5 h-5" />
            Products
          </Link>
          <Link to="/admin/settings" className={cn("flex items-center gap-3 px-4 py-3 rounded-2xl transition-all font-bold text-sm", location.pathname === '/admin/settings' ? 'bg-primary text-white shadow-lg shadow-primary/20' : 'text-slate-500 hover:bg-slate-100')}>
            <Settings className="w-5 h-5" />
            Settings
          </Link>
        </nav>
        <div className="p-6 border-t border-slate-100">
           <Link to="/" className="flex items-center gap-3 px-4 py-3 text-slate-500 font-bold text-sm hover:text-primary transition-colors">
              <LogOut className="w-5 h-5" />
              View Store
           </Link>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-grow p-4 md:p-12 overflow-y-auto">
        <Routes>
          <Route index element={<StatsOverview />} />
          <Route path="products" element={<ProductList />} />
          <Route path="products/new" element={<ProductForm />} />
          <Route path="products/edit/:id" element={<ProductForm />} />
        </Routes>
      </main>
    </div>
  );
};

// --- Sub-components ---

const StatsOverview = () => {
  const stats = [
    { label: 'Total Products', value: '142', icon: Package, color: 'bg-primary', trend: '+12 this month' },
    { label: 'Total Categories', value: '12', icon: BarChart3, color: 'bg-blue-500', trend: 'Healthy mix' },
    { label: 'In Stock', value: '1,240', icon: Check, color: 'bg-green-500', trend: 'Ready to ship' },
  ];

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="flex justify-between items-center">
        <h2 className="text-3xl font-display font-bold">Store Insights</h2>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {stats.map((stat, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            className="bg-white p-8 rounded-[40px] soft-shadow border border-slate-100"
          >
            <div className={cn("w-14 h-14 rounded-2xl flex items-center justify-center text-white mb-6", stat.color)}>
              <stat.icon className="w-7 h-7" />
            </div>
            <p className="text-slate-400 font-bold text-xs uppercase tracking-widest mb-2">{stat.label}</p>
            <p className="text-4xl font-display font-bold mb-4">{stat.value}</p>
            <p className="text-slate-400 text-sm">{stat.trend}</p>
          </motion.div>
        ))}
      </div>
    </div>
  );
};

const ProductList = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchProducts = async () => {
      setIsLoading(true);
      // Actual Supabase fetch would go here
      const { data } = await supabase.from('products').select('*').order('created_at', { ascending: false });
      
      if (data) {
        setProducts(data);
      } else {
        // Mocking for preview if DB is empty
        setProducts([
          { id: '1', name: 'COSRX Snail Mucin', price: 15500, category: 'Serums', stock: 45, images: ['https://images.unsplash.com/photo-1556228578-0d85b1a4d571?q=80&w=400&auto=format&fit=crop'], description: 'Classic' },
          { id: '2', name: 'BOJ Sunscreen', price: 18000, category: 'Protection', stock: 20, images: ['https://images.unsplash.com/photo-1556228720-195a672e8a03?q=80&w=400&auto=format&fit=crop'], description: 'Legendary' },
        ]);
      }
      setIsLoading(false);
    };

    fetchProducts();
  }, []);

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <h2 className="text-3xl font-display font-bold">Catalog</h2>
        <Link 
          to="/admin/products/new"
          className="bg-primary text-white px-8 py-3.5 rounded-full font-bold flex items-center gap-2 hover:shadow-xl hover:shadow-primary/30 transition-all"
        >
          <Plus className="w-5 h-5" />
          Add Magic Product
        </Link>
      </div>

      <div className="bg-white rounded-[40px] soft-shadow border border-slate-100 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="border-b border-slate-100">
                <th className="px-8 py-6 text-xs uppercase tracking-widest font-bold text-slate-400">Product</th>
                <th className="px-8 py-6 text-xs uppercase tracking-widest font-bold text-slate-400">Category</th>
                <th className="px-8 py-6 text-xs uppercase tracking-widest font-bold text-slate-400">Price</th>
                <th className="px-8 py-6 text-xs uppercase tracking-widest font-bold text-slate-400">Stock</th>
                <th className="px-8 py-6 text-xs uppercase tracking-widest font-bold text-slate-400">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {products.map((p) => (
                <tr key={p.id} className="hover:bg-slate-50 transition-colors group">
                  <td className="px-8 py-6">
                    <div className="flex items-center gap-4">
                       <div className="w-14 h-14 rounded-2xl bg-slate-100 overflow-hidden shrink-0 border border-slate-200 shadow-sm">
                         <img src={p.images[0]} alt="" className="w-full h-full object-cover" />
                       </div>
                       <span className="font-bold text-slate-700">{p.name}</span>
                    </div>
                  </td>
                  <td className="px-8 py-6">
                    <span className="px-4 py-1.5 bg-slate-100 text-slate-500 rounded-full text-[10px] font-bold uppercase tracking-wider">
                      {p.category}
                    </span>
                  </td>
                  <td className="px-8 py-6 font-bold text-slate-700">{formatPrice(p.price)}</td>
                  <td className="px-8 py-6">
                    <span className={cn("font-bold", p.stock < 10 ? 'text-orange-500' : 'text-slate-700')}>
                      {p.stock} units
                    </span>
                  </td>
                  <td className="px-8 py-6">
                    <div className="flex items-center gap-4">
                      <button 
                        onClick={() => navigate(`/admin/products/edit/${p.id}`)}
                        className="p-2.5 bg-blue-50 text-blue-500 rounded-xl hover:bg-blue-500 hover:text-white transition-all shadow-sm"
                      >
                        <Edit2 className="w-4 h-4" />
                      </button>
                      <button className="p-2.5 bg-red-50 text-red-400 rounded-xl hover:bg-red-500 hover:text-white transition-all shadow-sm">
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {isLoading && (
            <div className="flex items-center justify-center py-20 bg-white">
              <Loader2 className="w-10 h-10 animate-spin text-primary" />
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

const ProductForm = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [images, setImages] = useState<string[]>([]);
  const [formData, setFormData] = useState({
    name: '',
    price: '',
    category: 'Serums',
    stock: '',
    description: '',
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (id) {
      const fetchProduct = async () => {
        const { data } = await supabase.from('products').select('*').eq('id', id).single();
        if (data) {
          setFormData({
            name: data.name,
            price: data.price.toString(),
            category: data.category,
            stock: (data.stock || 0).toString(),
            description: data.description || '',
          });
          setImages(data.images || []);
        }
      };
      fetchProduct();
    }
  }, [id]);

  // Authenticator for ImageKit
  const authenticator = async () => {
    try {
      const response = await fetch('/api/imagekit/auth');
      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`Request failed with status ${response.status}: ${errorText}`);
      }
      const data = await response.json();
      const { signature, expire, token } = data;
      return { signature, expire, token };
    } catch (error: any) {
      throw new Error(`Authentication request failed: ${error.message}`);
    }
  };

  const handleUploadSuccess = (res: any) => {
    setImages(prev => [...prev, res.url].slice(0, 4));
  };

  const removeImage = (idx: number) => {
    setImages(prev => prev.filter((_, i) => i !== idx));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Simple validation
    if (!formData.name || !formData.price || images.length === 0) {
      alert("Please provide name, price and at least one image.");
      setIsSubmitting(false);
      return;
    }

    const payload = {
      ...formData,
      price: parseFloat(formData.price),
      stock: parseInt(formData.stock) || 0,
      images: images
    };

    try {
      if (id) {
         await supabase.from('products').update(payload).eq('id', id);
      } else {
         await supabase.from('products').insert([payload]);
      }
      navigate('/admin/products');
    } catch (err) {
      console.error(err);
      alert("Error saving product.");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="max-w-4xl animate-in slide-in-from-bottom-4 duration-500">
      <div className="flex items-center gap-4 mb-10">
         <button onClick={() => navigate(-1)} className="p-3 bg-white rounded-2xl border border-slate-200 text-slate-500 hover:bg-slate-100">
            <ChevronRight className="w-5 h-5 rotate-180" />
         </button>
         <h2 className="text-3xl font-display font-bold">
            {id ? 'Edit Secret Potion' : 'Create New Magic'}
         </h2>
      </div>

      <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-12">
        {/* Left Side: Info */}
        <div className="space-y-6">
          <div className="bg-white p-8 rounded-[40px] soft-shadow border border-slate-100 space-y-6">
            <div>
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-[0.2em] mb-2 block">Product Name</label>
              <input 
                value={formData.name}
                onChange={e => setFormData({...formData, name: e.target.value})}
                type="text" 
                placeholder="e.g. COSRX Snail Mucin" 
                className="w-full px-6 py-4 rounded-2xl bg-slate-50 border border-slate-100 focus:outline-none focus:ring-2 focus:ring-primary/20 transition-all"
              />
            </div>
            <div className="grid grid-cols-2 gap-6">
              <div>
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-[0.2em] mb-2 block">Price (₦)</label>
                <input 
                  value={formData.price}
                  onChange={e => setFormData({...formData, price: e.target.value})}
                  type="number" 
                  placeholder="15000" 
                  className="w-full px-6 py-4 rounded-2xl bg-slate-50 border border-slate-100 focus:outline-none focus:ring-2 focus:ring-primary/20 transition-all font-bold"
                />
              </div>
              <div>
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-[0.2em] mb-2 block">Stock Level</label>
                <input 
                  value={formData.stock}
                  onChange={e => setFormData({...formData, stock: e.target.value})}
                  type="number" 
                  placeholder="50" 
                  className="w-full px-6 py-4 rounded-2xl bg-slate-50 border border-slate-100 focus:outline-none focus:ring-2 focus:ring-primary/20 transition-all"
                />
              </div>
            </div>
            <div>
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-[0.2em] mb-2 block">Category</label>
              <select 
                value={formData.category}
                onChange={e => setFormData({...formData, category: e.target.value})}
                className="w-full px-6 py-4 rounded-2xl bg-slate-50 border border-slate-100 focus:outline-none focus:ring-2 focus:ring-primary/20 transition-all appearance-none cursor-pointer"
              >
                <option>K-Drinks</option>
                <option>K-Foods</option>
                <option>K-Snacks</option>
                <option>Cookies</option>
                <option>Bags & Holders</option>
                <option>Plushies</option>
                <option>Clothing</option>
                <option>Accessories</option>
                <option>Stationery</option>
                <option>Cups & Bottles</option>
                <option>Others</option>
              </select>
            </div>
            <div>
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-[0.2em] mb-2 block">Description</label>
              <textarea 
                value={formData.description}
                onChange={e => setFormData({...formData, description: e.target.value})}
                rows={4}
                placeholder="Share the magic benefits..." 
                className="w-full px-6 py-4 rounded-2xl bg-slate-50 border border-slate-100 focus:outline-none focus:ring-2 focus:ring-primary/20 transition-all resize-none"
              />
            </div>
          </div>
        </div>

        {/* Right Side: Images */}
        <div className="space-y-8">
           <div className="bg-white p-8 rounded-[40px] soft-shadow border border-slate-100">
             <div className="flex items-center justify-between mb-8">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-[0.2em]">Product Gallery</label>
                <span className="text-[10px] bg-primary/10 text-primary px-3 py-1 rounded-full font-bold">{images.length}/4</span>
             </div>

             <div className="grid grid-cols-2 gap-4 mb-8">
                {images.map((img, i) => (
                  <div key={i} className="aspect-square bg-slate-100 rounded-3xl relative overflow-hidden group border border-slate-200">
                    <img src={img} alt="" className="w-full h-full object-cover" />
                    <button 
                      type="button"
                      onClick={() => removeImage(i)}
                      className="absolute top-2 right-2 p-2 bg-red-500 text-white rounded-full opacity-0 group-hover:opacity-100 transition-all scale-75"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
                
                {images.length < 4 && (
                  <div className="aspect-square bg-slate-50 border-2 border-dashed border-slate-200 rounded-3xl flex flex-col items-center justify-center p-4 relative hover:bg-slate-100 transition-colors">
                     <ImageIcon className="w-8 h-8 text-slate-300 mb-2" />
                     <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest text-center leading-relaxed">
                        Drop image or click
                     </p>
                     <IKContext 
                        publicKey={import.meta.env.VITE_IMAGEKIT_PUBLIC_KEY} 
                        urlEndpoint={import.meta.env.VITE_IMAGEKIT_URL_ENDPOINT} 
                        authenticator={authenticator}
                      >
                       <IKUpload
                         onSuccess={handleUploadSuccess}
                         className="absolute inset-0 opacity-0 cursor-pointer"
                       />
                     </IKContext>
                  </div>
                )}
             </div>

             <div className="bg-primary/5 p-4 rounded-2xl border border-primary/10 flex gap-3">
                <Sparkles className="w-5 h-5 text-primary shrink-0" />
                <p className="text-[10px] text-primary/80 font-bold leading-relaxed uppercase">
                  Tip: Upload high-quality textures and packaging to increase trust.
                </p>
             </div>
           </div>

           <button 
             type="submit"
             disabled={isSubmitting}
             className="w-full bg-slate-900 text-white h-16 rounded-full font-bold flex items-center justify-center gap-3 transition-all hover:shadow-2xl hover:bg-slate-800 disabled:opacity-50"
           >
             {isSubmitting ? (
               <>
                 <Loader2 className="w-5 h-5 animate-spin" />
                 Saving Magic...
               </>
             ) : (
               <>
                 <Package className="w-5 h-5" />
                 {id ? 'Update Product' : 'Manifest Product'}
               </>
             )}
           </button>
        </div>
      </form>
    </div>
  );
};

const Check = ({ className }: { className?: string }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <polyline points="20 6 9 17 4 12" />
  </svg>
)
