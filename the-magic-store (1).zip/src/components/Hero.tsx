import React from 'react';
import { motion } from 'motion/react';
import { Link } from 'react-router-dom';
import { ShoppingBag, ArrowRight } from 'lucide-react';

export const Hero = () => {
  return (
    <section className="relative h-[85vh] flex items-center overflow-hidden">
      {/* Background blobs */}
      <div className="absolute top-0 right-0 -translate-y-1/4 translate-x-1/4 w-[600px] h-[600px] bg-primary/10 rounded-full blur-3xl -z-10" />
      <div className="absolute bottom-0 left-0 translate-y-1/4 -translate-x-1/4 w-[400px] h-[400px] bg-secondary/20 rounded-full blur-3xl -z-10" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row items-center gap-12">
        <motion.div 
          initial={{ opacity: 0, x: -50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8 }}
          className="flex-1 text-center md:text-left"
        >
          <motion.span 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.2 }}
            className="inline-block px-4 py-1.5 bg-accent text-primary rounded-full text-sm font-bold uppercase tracking-wider mb-6"
          >
            #1 K-Merch & Food Hub
          </motion.span>
          <h1 className="text-5xl md:text-7xl font-display font-bold leading-tight mb-6">
            Experience the <br/>
            <span className="text-primary italic italic">Magic of the BTS</span>
          </h1>
          <p className="text-xl text-text-muted mb-10 max-w-lg mx-auto md:mx-0">
            Discover authentic merchandise, the latest BTS collections, and the delicious flavors of Korea (The Magic Chow).
          </p>
          <div className="flex flex-col sm:flex-row items-center gap-6 justify-center md:justify-start">
            <Link 
              to="/shop"
              className="group bg-primary text-white px-8 py-4 rounded-full font-bold flex items-center gap-3 transition-all hover:pr-10 hover:shadow-lg hover:shadow-primary/30"
            >
              <ShoppingBag className="w-5 h-5" />
              <span>Shop All Products</span>
              <ArrowRight className="w-5 h-5 group-hover:translate-x-2 transition-transform" />
            </Link>
            <Link 
              to="/#categories"
              className="text-text font-bold flex items-center gap-2 hover:text-primary transition-colors"
            >
              Browse Categories
            </Link>
          </div>
        </motion.div>

        <motion.div 
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="flex-1 relative"
        >
          <div className="w-[300px] h-[400px] md:w-[450px] md:h-[550px] bg-secondary/30 rounded-t-[200px] rounded-b-[40px] overflow-hidden soft-shadow border border-white/40 glass">
            {/* Using a placeholder for now, user mentions ImageKit later */}
             <div className="w-full h-full bg-gradient-to-br from-secondary/50 to-primary/20 flex items-center justify-center">
                <SparkleIcon className="w-24 h-24 text-primary/40 animate-pulse" />
             </div>
          </div>
          
          {/* Floating elements */}
          <motion.div 
            animate={{ y: [0, -15, 0] }}
            transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
            className="absolute -top-10 -right-4 w-28 h-28 glass rounded-full p-4 flex items-center justify-center text-center leading-tight shadow-xl"
          >
             <span className="text-xs font-bold text-primary italic">#1 in Nigeria</span>
          </motion.div>
          
          <motion.div 
            animate={{ y: [0, 20, 0] }}
            transition={{ duration: 5, repeat: Infinity, ease: "easeInOut", delay: 1 }}
            className="absolute bottom-20 -left-10 bg-white p-4 rounded-2xl shadow-xl flex items-center gap-3 border border-secondary/20"
          >
            <div className="w-10 h-10 bg-accent rounded-full flex items-center justify-center">
              <SparkleIcon className="w-5 h-5 text-primary" />
            </div>
            <div>
              <p className="text-[10px] text-text-muted font-bold uppercase tracking-widest">New restock</p>
              <p className="text-sm font-bold">BT21 Plushies</p>
            </div>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
};

const SparkleIcon = ({ className }: { className?: string }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="M12 3c.132 0 .263 0 .393 0a7.5 7.5 0 0 0 7.92 12.446a9 9 0 1 1-8.313-12.454z"/>
    <path d="m19 10.5-2.9 1.4-1.4 2.9-1.4-2.9-2.9-1.4 2.9-1.4 1.4-2.9 1.4 2.9 2.9 1.4z"/>
    <path d="m12 18 .6 1.1 1.1.6-1.1.6-.6 1.1-.6-1.1-1.1-.6 1.1-.6.6-1.1z"/>
  </svg>
)
